Again, for some reason, some of the graphics - namely Fig. 29, 40, 41, 42, 44 - lost some segments when being compiled into PDF. These graphics can be found in their correct versions in the file missing.pdf.

Darij
